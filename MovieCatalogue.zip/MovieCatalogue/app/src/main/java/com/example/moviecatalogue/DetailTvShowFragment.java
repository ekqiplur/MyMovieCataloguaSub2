package com.example.moviecatalogue;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.moviecatalogue.model.TvShow;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailTvShowFragment extends Fragment {

    public TvShow tvShow;
    private TextView tvTitle, tvDeskripsi, tvRealese, tvGenre,
            tvStars, tvLanguage, tvRate;
    private ImageView ivPhoto;

    public static String EXTRA_TVSHOW = "extra tvshow";


    public DetailTvShowFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_tv_show, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvShow = getArguments().getParcelable(EXTRA_TVSHOW);

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(tvShow.getTitle());

        tvTitle = view.findViewById(R.id.tv_title);
        tvDeskripsi = view.findViewById(R.id.tv_description);
        tvRealese = view.findViewById(R.id.tv_release);
        tvGenre = view.findViewById(R.id.tv_genre);
        tvStars = view.findViewById(R.id.tv_stars);
        tvLanguage = view.findViewById(R.id.tv_language);
        tvRate = view.findViewById(R.id.tv_rate);

        ivPhoto = view.findViewById(R.id.iv_image);

        tvTitle.setText(tvShow.getTitle());
        tvRate.setText(tvShow.getRating());
        tvStars.setText(tvShow.getStars());
        tvGenre.setText(tvShow.getGenre());
        tvRealese.setText(tvShow.getRelease());
        tvLanguage.setText(tvShow.getLanguage());
        tvDeskripsi.setText(tvShow.getStoryline());

        Glide.with(this).load(tvShow.getPhoto()).into(ivPhoto);
    }
}
