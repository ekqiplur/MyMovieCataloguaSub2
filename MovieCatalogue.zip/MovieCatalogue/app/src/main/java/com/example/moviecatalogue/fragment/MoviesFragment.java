package com.example.moviecatalogue.fragment;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.moviecatalogue.DetailMovieActivity;
import com.example.moviecatalogue.R;
import com.example.moviecatalogue.adapter.MovieAdapter;
import com.example.moviecatalogue.model.Movie;

import java.util.ArrayList;

import static com.example.moviecatalogue.DetailMovieActivity.EXTRA_MOVIE;


public class MoviesFragment extends Fragment {

    private RecyclerView rvMovie;
    private ArrayList<Movie> list ;

    private String[] dataTitle;
    private String[] dataStory;
    private String[] dataRate;
    private String[] dataDirector;
    private String[] dataStars;
    private String[] dataGenre;
    private String[] dataRelease;
    private String[] dataLanguage;
    private String[] dataPhoto;

    private MovieAdapter movieAdapter;

    public MoviesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movies, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        prepare();
        addItem();
        rvMovie = view.findViewById(R.id.rv_movies);
        rvMovie.setHasFixedSize(true);
        movieAdapter= new MovieAdapter(list);
        rvMovie.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvMovie.setAdapter(movieAdapter);

        movieAdapter.setOnItemClickCallback(new MovieAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Movie movie) {
                Intent intent = new Intent(getActivity(), DetailMovieActivity.class);
                intent.putExtra(EXTRA_MOVIE, movie);
                startActivity(intent);
            }
        });
    }

    private void prepare() {
        dataTitle = getResources().getStringArray(R.array.title_movie);
        dataRate = getResources().getStringArray(R.array.rating_movie);
        dataDirector = getResources().getStringArray(R.array.director_movie);
        dataStars = getResources().getStringArray(R.array.stars_movie);
        dataGenre = getResources().getStringArray(R.array.genre_movie);
        dataRelease = getResources().getStringArray(R.array.release_movie);
        dataLanguage = getResources().getStringArray(R.array.language_movie);
        dataStory = getResources().getStringArray(R.array.storyline_movie);
        dataPhoto = getResources().getStringArray(R.array.photo_movie);
    }

    private void addItem() {
        list = new ArrayList<>();
        for (int i = 0; i < dataTitle.length; i++) {
            Movie movie = new Movie();
            movie.setTitle(dataTitle[i]);
            movie.setRating(dataRate[i]);
            movie.setDirector(dataDirector[i]);
            movie.setStars(dataStars[i]);
            movie.setGenre(dataGenre[i]);
            movie.setRelease(dataRelease[i]);
            movie.setLanguage(dataLanguage[i]);
            movie.setStoryline(dataStory[i]);
            movie.setPhoto(dataPhoto[i]);
            list.add(movie);
        }
    }
}
