package com.example.moviecatalogue.fragment;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.moviecatalogue.DetailTvShowFragment;
import com.example.moviecatalogue.R;
import com.example.moviecatalogue.adapter.TvShowAdapter;
import com.example.moviecatalogue.model.Movie;
import com.example.moviecatalogue.model.TvShow;

import java.util.ArrayList;

import static com.example.moviecatalogue.DetailTvShowFragment.EXTRA_TVSHOW;


/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowFragment extends Fragment {

    private RecyclerView rvTVshow;
    private ArrayList<TvShow> list ;

    private String[] dataTitle;
    private String[] dataStory;
    private String[] dataRate;
    private String[] dataStars;
    private String[] dataGenre;
    private String[] dataRelease;
    private String[] dataLanguage;
    private String[] dataPhoto;

    private TvShowAdapter tvShowAdapter;


    public TvShowFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tv_show, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        prepare();
        addItem();

        rvTVshow = view.findViewById(R.id.rv_tvshow);
        rvTVshow.setHasFixedSize(true);

        tvShowAdapter = new TvShowAdapter(list);
        rvTVshow.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvTVshow.setAdapter(tvShowAdapter);

        tvShowAdapter.setOnItemClickCallback(new TvShowAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(TvShow tvShow) {
                FragmentManager mFragmentManager = getFragmentManager();
                DetailTvShowFragment detailTvShowFragment = new DetailTvShowFragment();
                FragmentTransaction mFragmentTransaction = mFragmentManager.beginTransaction();
                mFragmentTransaction.replace(R.id.frame_container, detailTvShowFragment, DetailTvShowFragment.class.getSimpleName());
                mFragmentTransaction.addToBackStack(null);
                mFragmentTransaction.commit();

                Bundle bundle = new Bundle();
                bundle.putParcelable(EXTRA_TVSHOW,tvShow);
                detailTvShowFragment.setArguments(bundle);
            }
        });

    }

    private void prepare() {
        dataTitle = getResources().getStringArray(R.array.title_tv);
        dataRate = getResources().getStringArray(R.array.rating_tv);
        dataStars = getResources().getStringArray(R.array.stars_tv);
        dataGenre = getResources().getStringArray(R.array.genre_tv);
        dataRelease = getResources().getStringArray(R.array.release_tv);
        dataLanguage = getResources().getStringArray(R.array.language_tv);
        dataStory = getResources().getStringArray(R.array.storyline_tv);
        dataPhoto = getResources().getStringArray(R.array.image_tv);
    }

    private void addItem() {
        list = new ArrayList<>();
        for (int i = 0; i < dataTitle.length; i++) {
            TvShow tvShow = new TvShow();
            tvShow.setTitle(dataTitle[i]);
            tvShow.setRating(dataRate[i]);
            tvShow.setStars(dataStars[i]);
            tvShow.setGenre(dataGenre[i]);
            tvShow.setRelease(dataRelease[i]);
            tvShow.setLanguage(dataLanguage[i]);
            tvShow.setStoryline(dataStory[i]);
            tvShow.setPhoto(dataPhoto[i]);
            list.add(tvShow);
        }
    }
}
