package com.example.moviecatalogue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.moviecatalogue.model.Movie;

public class DetailMovieActivity extends AppCompatActivity {

    private Movie movie;
    private TextView tvTitle, tvDeskripsi, tvRealese, tvGenre,
            tvStars, tvDirector, tvLanguage, tvRate;
    private ImageView ivPhoto;

    public static String EXTRA_MOVIE = "extra movie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        movie = getIntent().getParcelableExtra(EXTRA_MOVIE);

        getSupportActionBar().setTitle(movie.getTitle());

        tvTitle = findViewById(R.id.tv_title);
        tvDeskripsi = findViewById(R.id.tv_description);
        tvRate = findViewById(R.id.tv_rate);
        tvDirector = findViewById(R.id.tv_director);
        tvStars = findViewById(R.id.tv_stars);
        tvRealese = findViewById(R.id.tv_release);
        tvGenre = findViewById(R.id.tv_genre);
        tvLanguage = findViewById(R.id.tv_language);
        ivPhoto = findViewById(R.id.iv_image);


        tvTitle.setText(movie.getTitle());
        tvRate.setText(movie.getRating());
        tvDirector.setText(movie.getDirector());
        tvStars.setText(movie.getStars());
        tvGenre.setText(movie.getGenre());
        tvRealese.setText(movie.getRelease());
        tvLanguage.setText(movie.getLanguage());
        tvDeskripsi.setText(movie.getStoryline());

        Glide.with(this).load(movie.getPhoto()).into(ivPhoto);

    }
}
